__version__ = '0.2.0'

from .loader import load, relational
from .map import tableIDs

